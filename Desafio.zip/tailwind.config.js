module.exports = {
    mode: 'jit',
    purge: ['./src/**/*.svelte'],
    theme: {
      extend: {},
    },
    variants: {},
    plugins: [],
  };
  